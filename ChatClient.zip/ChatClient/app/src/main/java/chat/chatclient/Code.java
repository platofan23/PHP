package chat.chatclient;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class Code extends AppCompatActivity implements View.OnClickListener {
    //Benötigte Variablen
    private Button login;
    private TextView view;
    String user;
    //Start-Methode
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        if(getIntent().hasExtra("mit") == true) {
            //Wert rausholen
            user  = getIntent().getExtras().getString("mit");
        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_code);
        //ID's setzen
        login=findViewById(R.id.login);
        view=findViewById(R.id.textView);
        //Button Listener setzen
        login.setOnClickListener(this);
    }
    //Listener Button
    @Override
    public void onClick(View v) {
        //Thread
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                String antwortServer="";
                //Benutzername und Passwort aus Fenster abrufen
                String benutzername= user;
                try  {
                    //Client anlegen
                    Client c=new Client();
                    //Socket aus Client-Klasse abrufen
                    Socket s=c.getSocket();
                    //Nachricht an Server schicken

                        //Writer anlegen
                        PrintWriter writer = new PrintWriter(s.getOutputStream());
                        //Übermitteln
                        writer.println("/e " + benutzername + ":");
                        //Flushen
                        writer.flush();
                    //Antwort auslesen
                    BufferedReader reader=new BufferedReader(new InputStreamReader(s.getInputStream()));
                    antwortServer=reader.readLine();
                    final String code=antwortServer;
                    runOnUiThread(new Runnable() {

                        @Override
                        public void run() {
                            // Stuff that updates the UI
                            String ausgabe=code;
                            view.setText(ausgabe);
                        }
                    });
                    //Verbindung beenden
                    s.close();
                    //Your code goes here
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        //Thread starten
        thread.start();
    }
}
