package chat.chatclient;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import java.io.PrintWriter;
import java.net.Socket;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Chat extends AppCompatActivity implements View.OnClickListener {
    //Benötigte Variablen
    private String namen;
    private String endausgabe;
    private String username;
    private Button send;
    private EditText name;
    private EditText write;
    private TextView ausgabe;
    private TextView datum;
    //Beim Starten
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //Prüfen ob Intent den gesuchten Wert hat
        if(getIntent().hasExtra("mit") == true) {
            //Wert rausholen
            username  = getIntent().getExtras().getString("mit");

        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);
        //ID's setzen
        name = findViewById(R.id.name);
        send = findViewById(R.id.send);
        write = findViewById(R.id.write);
        datum = findViewById(R.id.datum);
        ausgabe = findViewById(R.id.ausgabe);
        //Scrollbar setzen
        ausgabe.setMovementMethod(new ScrollingMovementMethod());
        //Button-Listener setzen
        send.setOnClickListener(this);
        //Datum Ausgeben
        setDatum();
        //Thread für Nachrichtenabruf
        ChatThread ct = new ChatThread(this);
        ct.start();
    }

    //Setter Message
    public void setzteMsg(String msg) {
        //String raussholen
        endausgabe = msg.substring(3, msg.length());
    }

    //Listener für Button Login
    @Override
    public void onClick(View v) {
        //Senden auslösen
        handlesend();
    }

    public void handlesend() {
        //Eintragen Name
        handlename();
        //Thread abspalten für das Socket
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    //Client anlegen
                    Client client = new Client();
                    //Socket aus Client holen
                    Socket s = client.getSocket();
                    //Writer zum schreoben von Nachrichten
                    PrintWriter writer = new PrintWriter(s.getOutputStream());
                    //Nachricht senden
                    if (write.getText() == null || write.getText().equals("") || write.getText().equals(" ") || write.getText().length() == 0) {
                        //Nichts passiert
                    } else {
                        //Wenn alles passt Nachricht an Server schreiben
                        writer.println("/n " + "[" + username  + "]<>" + namen + ": " + write.getText());
                        //Flushen
                        writer.flush();
                        //Schließen des Printers
                        writer.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
                //UI-Thread zum Updaten der GUI
                runOnUiThread(new Runnable() {

                    @Override
                    public void run() {
                        //Eingabe leeren
                        write.getText().clear();
                    }
                });
            }
        });
        //Thread startem
        thread.start();
    }

    //Ausgabe
    public void handleausgabe() {
        //UI-Thread zum Updaten der GUI
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                handlename();
                //Datum
                SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
                //Uhrzeit für die Ausgabe
                String uhrzeit = sdf.format(new Date());
                //Wenn das Ausgabefeld noch leer ist
                if (ausgabe.getText() == null) {
                    //Ausgabe setzen
                    ausgabe.setText("<" + uhrzeit + "> : " + endausgabe + " ");
                } else {
                    //Ausgabefeld erweitern
                    ausgabe.append("\n<" + uhrzeit + "> : " + endausgabe + " ");
                }
            }
        });
    }

    //Methode zur Namenseingabe
    public void handlename() {
        String vergleich=name.getText().toString();
        //Name auf Leere abgleichen
        if (vergleich.equals("") || vergleich == null || vergleich.equals(" ")) {
            //Name auf Anoymus setzen
            namen = "Anonymus";
        } else {
            //Name aus dem Textfeld abrufen
            namen = name.getText().toString();
        }
    }

    public void setDatum() {
        //Datum abrufen
        Date date = java.util.Calendar.getInstance().getTime();
        //Datum formatieren
        SimpleDateFormat dateFormatter = new SimpleDateFormat("dd.MM.yyyy");
        //Datum Ergebnis
        String dateString = dateFormatter.format(date);
        //Datum zur Ausgabe setzen
        datum.setText(dateString);
    }
}