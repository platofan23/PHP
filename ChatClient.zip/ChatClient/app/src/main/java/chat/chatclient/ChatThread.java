package chat.chatclient;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;

public class ChatThread extends Thread{
    //Variablen
    private Chat chat;
    //private ClientController c;
    //Konstruktor der Klasse AbrufThread
    public ChatThread(Chat chat){
        this.chat=chat;
    }

    //Run-Methode von dem Thread
    public void run(){
        //Dauerschleife für Nachschauen nach neuen Nachrichten
        while(true){
            try{
                //Client anlegen
                Client client = new Client();
                //Socket von Client holen
                Socket server = client.getSocket();
                String msg="";
                //Nachricht vom Server abrufen
                BufferedReader reader = new BufferedReader(new InputStreamReader(server.getInputStream()));
                msg = reader.readLine();
                reader.close();

                //Testen ob es eine Nachricht ist und ob diese null ist
                if(msg!=null&&msg.startsWith("/n")){
                    //Nachricht in ClientController setzen
                    chat.setzteMsg(msg);
                    //Ausgabemethode
                    chat.handleausgabe();
                    //Verbindung beenden
                    server.close();
                }
            }catch(IOException e){
                e.printStackTrace();
            }
        }
    }
}