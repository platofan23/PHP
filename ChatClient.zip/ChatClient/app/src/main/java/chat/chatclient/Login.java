package chat.chatclient;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import java.io.*;
import java.net.*;

public class Login extends AppCompatActivity implements View.OnClickListener {
    //Benötigte Variablen
    private Button login;
    private EditText username;
    private EditText password;
    private String aswerServer;

    //Start-Methode
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        //ID's setzen
        login=findViewById(R.id.login);
        username=findViewById(R.id.username);
        password=findViewById(R.id.password);
        //Button Listener setzen
        login.setOnClickListener(this);
    }

    //Setter MSG
    public void setzeAntwort(String zugriff) {
        aswerServer=zugriff;
    }

    //Listener Button
    @Override
    public void onClick(View v) {
        //Thread
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                String antwortServer="";
                //Benutzername und Passwort aus Fenster abrufen
                String benutzername= username.getText().toString();
                String passwort= password.getText().toString();
                try  {
                    //Client anlegen
                    Client c=new Client();
                    //Socket aus Client-Klasse abrufen
                    Socket s=c.getSocket();
                    //Nachricht an Server schicken
                    if((benutzername.equals("")||benutzername.equals(" ")||benutzername==null||benutzername.length()==0)||(passwort.equals("")||passwort.equals(" ")||passwort==null||passwort.length()==0)) {

                    }else{
                        //Writer anlegen
                        PrintWriter writer = new PrintWriter(s.getOutputStream());
                        //Übermitteln
                        writer.println("/l " + benutzername + ":" + passwort );
                        //Flushen
                        writer.flush();
                    }
                    //Antwort auslesen
                    BufferedReader reader=new BufferedReader(new InputStreamReader(s.getInputStream()));
                    antwortServer=reader.readLine();
                    setzeAntwort( antwortServer);
                    //Verbindung beenden
                    s.close();
                    //Your code goes here
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        //Thread startem
        thread.start();
        //Abgleich ob Antwort mit l startete
        if(aswerServer!=null&&aswerServer.startsWith("/l:")){
            String zugriff = "";
            //Array Typ Char
            char[] msg = new char[aswerServer.length()];
            for(int i=0;i<aswerServer.length();i++){
                //Char aus Nachricht nehmen
                char ch=aswerServer.charAt(i);
                //Char in den Array schreiben
                msg[i]=ch;
                if(i>2&&i<aswerServer.length()){
                    //String um Chars aus Array erweitern
                    zugriff=zugriff + msg[i];
                }
            }
            //Wenn Zugriff passt
            if(zugriff.equals("true")) {
                //Fenster wechseln
                Intent intent = new Intent(Login.this, auswahl.class);
                //Benutzername reinlegen
                String mit=username.getText().toString();
                //An Intent weitergeben
                intent = intent.putExtra("mit",mit);
                //Nächste Activity starten
                startActivity(intent);
            }
        }
    }
}


