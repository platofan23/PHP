package chat.chatclient;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class auswahl extends AppCompatActivity implements View.OnClickListener {
    private Button code;
    private Button chat;
    private String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        if (getIntent().hasExtra("mit") == true) {
            //Wert rausholen
            username = getIntent().getExtras().getString("mit");
        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.auswahl);
        code = findViewById(R.id.einmalcode);
        code.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Intent anlegen
                Intent intent = new Intent(auswahl.this, Code.class);
                //Benutzername reinlegen
                intent = intent.putExtra("mit", username);
                //Nächste Activity starten
                startActivity(intent);
            }
        });

        chat = findViewById(R.id.chat);
        chat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Intent anlegen
                Intent intent = new Intent(auswahl.this, Chat.class);
                //Benutzername reinlegen
                intent = intent.putExtra("mit", username);
                //Nächste Activity starten
                startActivity(intent);
            }
        });
    }
    //Nur zu Vollständigkeit
    @Override
    public void onClick(View view) {

    }
}
