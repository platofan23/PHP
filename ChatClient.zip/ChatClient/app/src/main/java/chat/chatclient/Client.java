package chat.chatclient;

import java.net.*;
import java.io.*;

public class Client{
    //Variablen
    Socket server=new Socket("platofan23.ddns.net",5555);

    //Konstruktor Klasse Client
    public Client() throws IOException{

    }

    //Getter Socket
    public  Socket getSocket(){
        return server;
    }

    //Main-Methode
    public static void main(String[] args){
        try{
            Client clientserver=new Client();
        }catch(IOException e){
            System.out.println(e);
        }
    }
}
