package d.www.lib;

public class MyClass {
}
